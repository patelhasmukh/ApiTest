
package pojo.endpoint.bus;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DPPrims_ {

    @SerializedName("list")
    @Expose
    private List<List____> list = null;

    public List<List____> getList() {
        return list;
    }

    public void setList(List<List____> list) {
        this.list = list;
    }

}
