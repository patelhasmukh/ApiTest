
package pojo.endpoint.bus;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RouteSeatTypeDetail_ {

    @SerializedName("list")
    @Expose
    private List<List_____> list = null;

    public List<List_____> getList() {
        return list;
    }

    public void setList(List<List_____> list) {
        this.list = list;
    }

}
